var RandomForestClassifier = require('./forest'),
    DecisionTreeClassifier = require('./tree');

module.exports.RandomForestClassifier = RandomForestClassifier;
module.exports.DecisionTreeClassifier = DecisionTreeClassifier;